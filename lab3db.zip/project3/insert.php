<?php
include 'config.php';

$name = $_REQUEST["name"];
$email = $_REQUEST["email"];
$date = $_REQUEST["date"];
$nif = $_REQUEST["nif"];

$sql = "INSERT INTO table3 (name,email,date,nif)
VALUES ('$name','$email','$date','$nif')";

$ret = mysqli_query($link,$sql);

if ($ret){
    $last_id = mysqli_insert_id($link);
    echo "Thank you. the following query data is:
    <br>name: $name
    <br>email: $email
    <br>date: $date
    <br>nif: $nif
    <br>
    You have the number $last_id, that you should use as a reference. ";

} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
}
?>