<?php
include 'config.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM table3 WHERE id = $id";
    $result = mysqli_query($link, $sql);

    if ($row = mysqli_fetch_array($result));

        $id = $row['id'];
        $name = $row['name'];
        $email = $row['email'];
        $date = $row['date'];
        $nif = $row['nif'];

        echo "<h1>User Details</h1>";
        echo "<p><strong>Id:</strong> $id</p>";
        echo "<p><strong>Name:</strong> $name</p>";
        echo "<p><strong>Email:</strong> $email</p>";
        echo "<p><strong>Date:</strong> $date</p>";
        echo "<p><strong>NIF:</strong> $nif</p>";
    } else {
        echo "No user found with the provided ID.";
    }
?>