<?php
include 'config.php';

$sql = "SELECT * FROM table3";
$result = mysqli_query($link, $sql);

echo "<h1>User List</h1>";

while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $name = $row['name'];
    $date = $row['date'];

    echo "<a href='detail.php?id=$id'>$id | $name | $date</a><br>";
}
?>