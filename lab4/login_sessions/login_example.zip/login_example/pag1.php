<?
include ("autentica.php");
?>
this is the page 1 