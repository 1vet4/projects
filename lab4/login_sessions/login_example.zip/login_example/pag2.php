<?
include ("autentica.php");
?>
This is the page 2