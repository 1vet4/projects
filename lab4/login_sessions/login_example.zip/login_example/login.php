		<h3>Login</h3>
		<form action='pag1.php' method='post'>
			Username: <input type='text' name='user'><br>
			Password: <input type='password' name='pass'><br><br>
			<input type='submit' value='login'>
		</form>