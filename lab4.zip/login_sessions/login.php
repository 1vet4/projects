<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form method="post" action="login.php">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username"><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br><br>
        <input type="submit" value="Submit">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $link = mysqli_connect('localhost', 'root', '', 'usersdb') or die("Couldn't connect to the database");

        $hashedPassword = md5($password);

        $sql="SELECT id FROM users WHERE password='$password' AND username='$username'";
	    $result = mysqli_query($link, $sql);

        if (mysqli_num_rows($result) === 1) {
            header('Location: afterlogin.php');
            exit;
        } else {
            echo 'Invalid username or password';
        }
    }
    ?>
</body>
</html>